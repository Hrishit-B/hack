from curdrice.app import *

if __name__ == "__main__":
    curdrice()